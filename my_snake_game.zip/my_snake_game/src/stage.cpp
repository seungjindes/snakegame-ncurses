
#include "stage.h"


Stage::Stage()
{
    nowStage = 0;
}

Stage::~Stage()
{
}

void Stage::Update(float eTime)
{
}

void Stage::Render()
{
}
